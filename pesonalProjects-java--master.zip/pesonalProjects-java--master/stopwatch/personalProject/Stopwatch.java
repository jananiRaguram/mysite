package personalProject;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.util.concurrent.TimeUnit;
import java.text.DecimalFormat;


/*
 * layout of buttons from https://hajsoftutorial.com/actionevent-getsource/
 * 	changing the display on JFrame to be same as the updated time
 *	from https://www.geeksforgeeks.org/java-applet-digital-stopwatch/ 
 */
public class Stopwatch extends JFrame implements Runnable, ActionListener{
	
	private boolean running = false; 
	private int stopClicked; 
	private JButton stopButton, startButton;
	int min, sec, ms; 
	JLabel timeLabel = new JLabel();
	JFrame display = new JFrame("Stopwatch");
	String tFormatted;
	
	/*creating frame and private voids to run */
	public void frame(){
		display.setLayout(new FlowLayout());
		setButtons();
		setActions();
		display.setSize(600,400);
		display.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	private void setButtons() {
		
		JPanel bPanel = new JPanel();
		startButton = new JButton("start");
		stopButton = new JButton("stop");

		bPanel.add(startButton);
		bPanel.add(stopButton);
		display.add(bPanel);
		
		/*stop graphics*/
		startButton.setBackground(Color.GREEN);
		startButton.setOpaque(true);
		/*stop graphics*/
		stopButton.setBackground(Color.RED);
		stopButton.setOpaque(true);
		
		JPanel tPanel = new JPanel();
		tPanel.add(timeLabel);
		display.add(tPanel);
		tFormatted = "00:00.00";
		Dimension size = timeLabel.getPreferredSize();
		timeLabel.setText(tFormatted);
		timeLabel.setBounds(150,100,size.width, size.height);
		
		new Thread(this, "StopWatch").start();
	}
	
	private void setActions() {
		startButton.addActionListener(this);
		stopButton.addActionListener(this);
	}
	
	/*actions buttons will perform*/
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == startButton) {
			running = true; 
			new Thread(this, "StopWatch").start();
			stopClicked = 0;
			System.out.println(stopClicked);
		}else if(e.getSource() == stopButton){
			stopClicked++;
			running = false;

			/*for restarting*/
			if (e.getSource() == stopButton && stopClicked > 1){
				running = false;
				stopClicked = 0;
				min = sec = ms = 0;
				changeDisp();
			}
		}
	}	
	
	/*updating the each variable for as time moves forward*/

	public void updateTime(){
		ms++;
		if(ms == 100) {
			ms = 0;
			sec++;
			if(sec == 60) {
				sec = 0;
				min++;
			}
		}
	}
	

	public void changeDisp() {
		/*formats each time variable into 2 digits*/
		if(min < 10) {
			/*show 00:00.00*/
			tFormatted = "0" + min +  ":";
		}else {
			tFormatted = min + ":";
		}
		
		if(sec < 10) {
			tFormatted  += "0" + sec + ".";
		}else {
			tFormatted  += sec + ".";
		}
		
		if(ms < 10) {
			tFormatted += "0" + ms; 
		}else {
			DecimalFormat dFormat = new DecimalFormat("00");
			tFormatted += dFormat.format(ms);
		}
		timeLabel.setText(tFormatted);
	}
	
	public void run() {
		while(running) {
			try{
				TimeUnit.MILLISECONDS.sleep(10);
				updateTime();
				changeDisp();
			}
			catch(InterruptedException ex){
			    Thread.currentThread().interrupt();
			}
		}
		
	}
	public static void main(String[] args) {
		Stopwatch display = new Stopwatch();
		display.frame();
	}
}
	
