package personalProject;
//
//import java.io.IOException;
//import java.io.FileReader;
//import java.io.BufferedReader;
import java.util.Scanner;
import java.io.File;

public class Grid {
	public static void main(String[] args) {
		Scanner pattern = new Scanner(System.in);
		System.out.println("enter pattern name:");
		String userPattern = pattern.nextLine();
		String filePath = "C:\\Users\\Janani\\eclipse-workspace\\CGOL\\src\\personalProject\\";
		userPattern = userPattern.concat(".rle");
		userPattern = filePath.concat(userPattern);
		System.out.println(userPattern);
		try {
			File read = new File(userPattern);
			Scanner sc = new Scanner(read);
			while(sc.hasNextLine()) {
				System.out.println(sc.nextLine());
			}
			sc.close();
			pattern.close();
		}catch(Exception e) { 
            System.out.println("Exception thrown:\n" + e); 
			
		}
		
	}
}
